


var paragraph = document.getElementsByClassName('text');


//console.log(paragraph);

console.log(paragraph[0]);


// paragraph[0].style.color = 'red';

// paragraph[0].style.color = 'blue';

// paragraph[0].style.color = 'green';

// paragraph[0].style.background = 'black';

// paragraph[0].style.background = 'yellow';

// paragraph[0].style.fontSize = "xx-large";

// paragraph[0].style.fontSize = "100px";

// paragraph[0].style.fontWeight = "900";

// paragraph[0].style.fontFamily = "Courier New, Impact, Charcoal,sans-serif";



