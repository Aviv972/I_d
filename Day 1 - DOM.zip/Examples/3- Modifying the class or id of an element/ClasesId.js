var secondParagraph = document.getElementById('second');

// Modify class of an element

secondParagraph.className = 'text red-background';



//Add or modify ID

// var firstParagraph = document.getElementsByClassName('text')[0];

// firstParagraph.id = 'first';